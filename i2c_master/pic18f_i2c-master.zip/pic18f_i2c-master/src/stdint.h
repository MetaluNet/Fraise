/*
** Made by fabien le mentec <texane@gmail.com>
** 
** Started on  Wed Nov 11 14:05:00 2009 texane
** Last update Wed Nov 11 15:17:41 2009 texane
*/



#ifndef STDINT_H_INCLUDED
# define STDINT_H_INCLUDED



typedef unsigned char uint8_t;
typedef unsigned int uint16_t;



#endif /* ! STDINT_H_INCLUDED */
